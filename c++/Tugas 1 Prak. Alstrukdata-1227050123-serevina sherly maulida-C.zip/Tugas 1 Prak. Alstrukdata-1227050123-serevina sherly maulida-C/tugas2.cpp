#include <iostream>

using namespace std;
int main()
{
 int k = 1;
	while (k <= 10){
		cout << "HALO"<<endl;
		k = k+1;
	}
	return 0;
}