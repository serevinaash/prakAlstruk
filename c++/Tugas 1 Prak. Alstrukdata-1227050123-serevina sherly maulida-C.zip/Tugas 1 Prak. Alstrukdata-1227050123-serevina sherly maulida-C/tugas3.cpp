#include <iostream>

using namespace std;
int main(){
	
	int bil_hasil,sisa_bagi,bilangan;
	
	
	cout<<"Masukan Bilangan : ";
	cin>>bilangan;
	if(bilangan%2 == 0){
		cout << "Bilangan ini Adalah bilangan genap";
	}else{
		cout << "bilangan ini adalah bilangan ganjil";
	}
	return 0;
}
	
	
	
	